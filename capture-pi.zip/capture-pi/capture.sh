#!/bin/bash
cd ~/fp
rm -rf Data Data.zip
mkdir Data
echo "Capturing image"
python light_and_image.py
echo "Creating zip"
zip -r Data.zip Data
echo "Data ready"
