import unicornhathd as unicorn
from picamera2 import Picamera2
import time
import numpy as np

picam2 = Picamera2()
modes = picam2.sensor_modes
mode = modes[1]
print('mode selected: ', mode)
camera_config = picam2.create_still_configuration(
        raw={'format': mode['unpacked']},
        sensor={'output_size': mode['size'],
                'bit_depth': mode['bit_depth']}
        )
picam2.configure(camera_config)

time.sleep(2) # let camera warm up for a couple seconds

dim = 16

def spiral(center,size):
    # Always goes right and down so pick lower index center pixel
    order = np.empty((size**2,2))
    row,col = center
    dirBorder = [
        col+1, # right
        row+1, # down
        col-1, # left
        row-1  # up
    ]
    dirIdx = 0
    i = 0
    while col < size and col >= 0 and row < size and row >= 0:
        # print(f'({row},{col})')
        # order[i] = col + row*size
        order[i] = np.array([row, col])
        i += 1
        if dirIdx == 0:
            col += 1
            d = col
        elif dirIdx == 1:
            row += 1
            d = row
        elif dirIdx == 2:
            col -= 1
            d = col
        elif dirIdx == 3:
            row -= 1
            d = row
        if d == dirBorder[dirIdx]:
            if dirIdx > 1:
                dirBorder[dirIdx] -= 1
            else:
                dirBorder[dirIdx] += 1
            dirIdx = (dirIdx + 1) % 4
    return order

def light(i, j):
    unicorn.set_pixel(i, j, 0, 255, 0)
    unicorn.show()

def image(num):
    picam2.start()
    time.sleep(0.2)
    # picam2.capture_file(f"Data/test{num:03d}.jpg")
    raw = picam2.capture_array("raw").view(np.uint16)
    np.save(f'Data/{num:03d}.npy',raw)
    # TODO: take name as input so stuff gets stored in more meaningful place

def finish(i, j):
    unicorn.set_pixel(i, j, 0, 0, 0)
    unicorn.show()

def run():
    center = (dim-0.5)//2
    order = spiral((center,center),dim)
    count = 0
    for pixel in order:
        i,j = pixel[0],pixel[1]
        light(i, j)
        image(count)
        finish(i, j)
        count += 1

if __name__ == '__main__':
    unicorn.clear()
    run()

