import io
import unicornhathd as unicorn
from picamera2 import Picamera2
from flask import Flask, Response, request
import cv2
import os
import signal

app = Flask(__name__)

picam2 = Picamera2()
camera_config = picam2.create_preview_configuration(main={"format": 'XRGB8888', "size": (640, 480)})
picam2.configure(camera_config)
picam2.start()

def generate_frames():
    while True:
        frame = picam2.capture_array()
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return Response(
        """
        <html>
            <body>
                <h1>Video Stream</h1>
                <img width="640" height="480" src="/video">
                </img>
                <br>
                <button id="actionButton">End</button>
                <script>
                    document.getElementById("actionButton").onclick = function() {
                        fetch('/end')
                            .then(response => response.json())
                            .then(data => alert(data.message));
                    }
                </script>
            </body>
        </html>
        """, content_type='text/html')

@app.route('/video')
def video():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/end')
def end():
    print("Shutting down stream")
    picam2.close()
    os.kill(os.getpid(), signal.SIGINT)
    exit()

if __name__ == '__main__':
    unicorn.set_pixel(7, 7, 255, 255, 255)
    unicorn.show()
    app.run(host='0.0.0.0', port=5000)

