import unicornhathd as unicorn
from picamera2 import Picamera2
import time
import numpy as np
from pprint import *

picam2 = Picamera2()

modes = picam2.sensor_modes
mode = modes[1]
print('mode selected: ', mode)
camera_config = picam2.create_still_configuration(
        raw={'format': mode['unpacked']},
        sensor={'output_size': mode['size'],
                'bit_depth': mode['bit_depth']}
        )
picam2.configure(camera_config)

time.sleep(2) # let it warm up for a couple seconds

def light(i, j):
    unicorn.set_pixel(i, j, 0, 0, 255)
    unicorn.show()

def image():
    picam2.start()
    time.sleep(0.2)
    raw = picam2.capture_array("raw").view(np.uint16)
    np.save('test_capture.npy',raw)

def finish(i, j):
    unicorn.set_pixel(i, j, 0, 0, 0)
    unicorn.show()

def run():
    light(7,7)
    image()
    finish(7,7)

if __name__ == '__main__':
    unicorn.clear()
    run()
    unicorn.clear()
    unicorn.show()
    picam2.close()

